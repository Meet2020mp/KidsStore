package com.kidsstore.Kidsstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KidsstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
